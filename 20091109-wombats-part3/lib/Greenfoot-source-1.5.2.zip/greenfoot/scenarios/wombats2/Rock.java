import greenfoot.*;  // imports Actor, World, Greenfoot, GreenfootImage

/**
 * Rock - a class for representing rocks.
 *
 * @author Michael Kolling
 * @version 1.0.1
 */
public class Rock extends Actor
{
    public Rock()
    {
    }
}