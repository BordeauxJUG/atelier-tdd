
 Ceska lokalizace pro BlueJ 2.1.2
=================================

Verze 1.00 ze dne 11.1.2006.

Lokalizaci vytvorili Petr Skoda a Rudolf Pecinovsky.


Aktualizace a dalsi informace ziskate na adresach:

  * http://vyuka.pecinovsky.cz
  * http://www.rdv.vslib.cz/skodak
